#!/bin/bash
sudo cp Tango2 /usr/share/icons/
echo '===================================='
echo ' OK DONE INSTALL SUKSES '
echo '===================================='
